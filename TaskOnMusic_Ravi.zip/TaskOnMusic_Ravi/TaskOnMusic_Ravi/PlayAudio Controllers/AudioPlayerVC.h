//
//  AudioPlayerVC.h
//  TaskOnMusic_Ravi
//
//  Created by Pramodkumar kandukuru on 5/17/17.
//  Copyright © 2017 Pramodkumar kandukuru. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVFoundation/AVAudioPlayer.h>

@interface AudioPlayerVC : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *playPauseAudioBtn;
@property (weak, nonatomic) IBOutlet UISlider *progressSlider;
@property (weak, nonatomic) IBOutlet UILabel *currentTimeLbl;
@property (weak, nonatomic) IBOutlet UILabel *durationLbl;
@property (weak, nonatomic) IBOutlet UIImageView *bgImgView;

- (IBAction)playPausBtnAction:(UIButton *)sender;

- (IBAction)progressValueChange:(UISlider *)sender;
@property (weak, nonatomic) IBOutlet UIButton *previousSongBtn;
@property (weak, nonatomic) IBOutlet UIButton *nextSongBtn;

@property (weak, nonatomic) IBOutlet UILabel *songNameLbl;

//@property (strong,nonatomic) AVPlayer *player;
@property (strong,nonatomic) AVAudioPlayer *audioPlayer;
@property (strong,nonatomic) NSTimer *sliderTimer;

-(NSString*)stringFromIntervel:(NSTimeInterval)intervel;

-(void)updateSlider;
@end
