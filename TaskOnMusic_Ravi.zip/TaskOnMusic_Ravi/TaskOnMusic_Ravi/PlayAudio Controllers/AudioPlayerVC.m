//
//  AudioPlayerVC.m
//  TaskOnMusic_Ravi
//
//  Created by Pramodkumar kandukuru on 5/17/17.
//  Copyright © 2017 Pramodkumar kandukuru. All rights reserved.
//

#import "AudioPlayerVC.h"

@interface AudioPlayerVC ()<AVAudioPlayerDelegate>
{
  //---- Array_PathPlayingFiles is for keep all songs file paths and play song index related
    NSMutableArray *Array_PathPlayingFiles;
    
    //---- this is for get current index file path of the song
    NSString *str_FilePath;
    
    //---- assign number with song is to be play
    NSInteger CurrentIndexOfArray;
}

@end

@implementation AudioPlayerVC

- (void)viewDidLoad {
    [super viewDidLoad];

    Array_PathPlayingFiles=[[NSMutableArray alloc]init];

    
    // Prepare files path to Play
    NSMutableArray *Array_Temp = [[NSMutableArray alloc]init];
    
    NSString *filePath = nil;
    
    int totalSongs_Count = 5;
    
    
    //----- Here Iam getting all songs in to single array
    for (int i=0; i<= totalSongs_Count; i++)
    {
        filePath = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"song%d", i]                                                              ofType:@"mp3"];
        
        [Array_Temp addObject:filePath];
    }
    
    Array_PathPlayingFiles = Array_Temp;
    
    CurrentIndexOfArray =0;
    
    //------ here save the initial song file path
    str_FilePath = [Array_PathPlayingFiles objectAtIndex:CurrentIndexOfArray];
    
    [self playAudio];
}


///---------- this method is for calling every time when the user is taps next or previous songs

-(void)playAudio
{
    NSError *error;
    
    NSURL *fileURL = [[NSURL alloc] initFileURLWithPath: str_FilePath];
    
    self.audioPlayer = [[AVAudioPlayer alloc]initWithContentsOfURL:fileURL error:&error];
    
    //------------ this is for play song when app is in background state
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive: YES error: nil];
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    
    
    UIBackgroundTaskIdentifier newTaskId = UIBackgroundTaskInvalid;
    if([self.audioPlayer play]){
        newTaskId = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:NULL];
    }
    
    self.audioPlayer.delegate=self;
    
    self.audioPlayer.numberOfLoops = -1;

    
    self.durationLbl.text=[self stringFromIntervel:self.audioPlayer.duration];
    
    self.progressSlider.maximumValue=self.audioPlayer.duration;
    
    self.progressSlider.value=0.0;
    
    
    if (self.audioPlayer.duration<=3600) {
        
        self.currentTimeLbl.text=[NSString stringWithFormat:@"00:00"];
    }else{
        self.currentTimeLbl.text=[NSString stringWithFormat:@"0:00:00"];
    }
    
    [self.audioPlayer prepareToPlay];
    
    [_audioPlayer play];
    
    _songNameLbl.text=[NSString stringWithFormat:@"Song %ld",(long)CurrentIndexOfArray];
    
    _bgImgView.image=[UIImage imageNamed:[NSString stringWithFormat:@"bgimg%ld.jpeg",(long)CurrentIndexOfArray]];
    
    
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(moveSlider) userInfo:nil repeats:YES];
    
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTimeLeft) userInfo:nil repeats:YES];
}


//--------- update the progress of the song duration time
-(void)moveSlider
{
    self.progressSlider.value=self.audioPlayer.currentTime;
}


//----- to know the song how minutes are left of the song
- (void)updateTimeLeft
{
    self. currentTimeLbl.text = [self stringFromIntervel:self.audioPlayer.currentTime];
    
    NSTimeInterval timeLeft = self.audioPlayer.duration - self.audioPlayer.currentTime;
    
    int min=timeLeft/60;
    
    int sec = lroundf(timeLeft) % 60;
    
    // update your UI with timeLeft
    self. durationLbl.text = [NSString stringWithFormat:@"%d:%d", min,sec];
}

-(NSString*)stringFromIntervel:(NSTimeInterval)intervel
{
    NSInteger ti=(NSInteger)intervel;
    int second=ti%60;
    int minute=(ti/60)%60;
    long hour=(ti/3600);
    
    if (ti<=3600) {
        return [NSString stringWithFormat:@"%02d:%02d",minute,second];
    }else
        return [NSString stringWithFormat:@"%ld:%02d:%02d",hour,minute,second];
}

- (IBAction)playPausBtnAction:(UIButton *)sender
{
    if (!self.audioPlayer.playing) {
        
        [self.audioPlayer play];

        //self.progressSlider.maximumValue=self.audioPlayer.duration;
        
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateSlider) userInfo:nil repeats:YES];
        
        
        [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
        
    }
    else if (self.audioPlayer.playing)
    {
        [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
        
        [self.audioPlayer pause];
    }
}

-(void)updateSlider
{
    self.progressSlider.value=self.audioPlayer.currentTime;
    self.currentTimeLbl.text=[self stringFromIntervel:self.audioPlayer.currentTime];
}


- (IBAction)progressValueChange:(UISlider *)sender
{
    [self.audioPlayer stop];
    [self.audioPlayer setCurrentTime:self.progressSlider.value];
    [self.audioPlayer prepareToPlay];
    [self.audioPlayer play];
    
    [self updateImagesIfItIsPlay];
}

-(void)updateImagesIfItIsPlay
{
     if (self.audioPlayer.playing)
    {
        [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    }
     else
     {
    [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Play.png"] forState:UIControlStateNormal];
    }
}

//----- this method is for put condition for decrease the count of the song(play previous)
- (IBAction)previousSongPlayAction:(UIButton *)sender {
    
    [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    
    NSLog(@"CurrentIndexOfArray=%ld",(long)CurrentIndexOfArray);

    if ( CurrentIndexOfArray == 0)
    {
        CurrentIndexOfArray = [Array_PathPlayingFiles count]-1;
    }
    else
    {
        CurrentIndexOfArray--;
    }
    str_FilePath = [Array_PathPlayingFiles objectAtIndex:CurrentIndexOfArray];
    
    [self playAudio];
    //[self toggling_Playback];
}


//----- this method is for put condition for increase the count of the song(play next)
- (IBAction)nextSongPlayAction:(UIButton *)sender {
    
    [self.playPauseAudioBtn setImage:[UIImage imageNamed:@"Pause.png"] forState:UIControlStateNormal];
    
    NSLog(@"CurrentIndexOfArray=%ld",(long)CurrentIndexOfArray);
    
    if ( CurrentIndexOfArray == [Array_PathPlayingFiles count]-1)
    {
        CurrentIndexOfArray = 0;
    }
    else
    {
        CurrentIndexOfArray++;
    }
    str_FilePath = [Array_PathPlayingFiles objectAtIndex:CurrentIndexOfArray];
    
    
    [self playAudio];
    // [self toggling_Playback];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
